source ~/.bashrc
echo 'Komenda: clang++ -std=c++11 -Wall -Wextra -Wshadow -D_GLIBCXX_DEBUG plik.cpp -o plik'
