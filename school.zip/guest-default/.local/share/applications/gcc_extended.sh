source ~/.bashrc
echo 'Komenda: g++ -std=c++11 -static -m32 -O2 plik.cpp -o plik'
