source ~/.bashrc
echo 'Command: g++ -std=c++11 plik.cpp -o plik'
