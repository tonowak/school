source ~/.bashrc
echo 'Komenda: clang++ -std=c++11 plik.cpp -o plik'
